interface Messageable {
  String message(String from, String body);
}
