public class LevelTester {
  public static void main(String[] args) {
    Tracker testTracker = new WaterTracker();
    System.out.println(testTracker);
  }
}
